mod taskmanager;
use taskmanager::setup::run;

fn main() {
    run();
}
